import { Request, Response } from 'express';
import sql, { ConnectionPool } from 'mssql';
import sqlConfig from '../config/sqlconfig';
import * as jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

//#region POST

const UserLogin = async (req: Request, res: Response) => {
  let pool!: ConnectionPool;
  const UserData = req.query;
  try {
    pool = await sql.connect(sqlConfig);
    const Result = await pool
      .request()
      .input('UserID', sql.NVarChar(50), UserData.UserID)
      .input('Password', sql.NVarChar(50), UserData.Password)
      .output('Status', sql.VarChar(500), UserData.Status)
      .execute('sp_GetFindUser');

    const token = jwt.sign({ UserID: UserData.UserID }, 'EFWS_Vinesh_Patel' as string, {
      expiresIn: '1h',
    });

    const { recordset, recordsets } = Result;

    if (!recordset.length) {
      res.status(404).send({
        message: 'User Not Found',
      });
      return;
    }

    res.status(200).json({
      message: 'User Found',
      Table: recordsets,
      Token: token,
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (error: any) {
    res.status(500).send({
      message: error.message,
    });
  } finally {
    pool?.close();
  }
};

export { UserLogin };

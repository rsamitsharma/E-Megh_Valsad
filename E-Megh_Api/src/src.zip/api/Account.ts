import express from 'express';
import { UserLogin } from '../controller/AccountController';

const itemsRouter = express.Router();

itemsRouter.get('/GetUser', UserLogin);

export default itemsRouter;
